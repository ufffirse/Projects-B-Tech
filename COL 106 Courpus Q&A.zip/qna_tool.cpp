#include <assert.h>
#include <sstream>
#include "qna_tool.h"
using namespace std;
vector<string>sen_to_word(string& k){
    string word="";
    vector<string >words;
    for(char c : k){
        if(isalpha(c)){
            int i=c;
            if(i<97){
                i=i+32;
            }
            c=char(i);
            word=word+c;
        }
        else{
            if(!word.empty()){
                words.push_back(word);
                word="";
            }
        }}
    words.push_back(word);
    return words;
}

QNA_tool::QNA_tool(){
process=false;
parag faltu(-1,-1,-1);
vec.push_back(faltu);
kam.assig(200007);}
QNA_tool::~QNA_tool(){
    // Implement your function here  
}
void QNA_tool::insert_sentence(int b_code, int pg, int para, int sentence_no, string& sen){
      if(para==vec.back().par->paragraph&&pg==vec.back().par->page){
        vec.back().add(sen);
    }
    else{
        parag k(b_code,pg,para);
        vec.push_back(k);
        vec.back().add(sen);
    }
    kam.insert_sentence(sen);
    return;
}

Node* QNA_tool::get_top_k_para(string question, int k) {
    if(!process){
        process=true;
        processCSVFile("unigram_freq.csv");
    }
    vector<string>words=sen_to_word(question);
       heap s(k);
       int n=vec.size();
    // ofstream out("score.txt") ;
    for(int i=1;i<n;i++){
        long double m =vec[i].score(words,kam);
        vec[i].par->sentence_no= m;
        // out<<vec[i].par->book_code<<" "<<vec[i].par->page<<" "<<vec[i].par->paragraph<<" "<<m<<endl;
        s.push(vec[i].par,m);
    }
    Node* head=nullptr;
    Node* temp;
    for(int i=0;i<k;i++){
        temp=s.get();
        if(temp==nullptr){
            break;
        }
        temp->right=head;
        head=temp;
    }
    return temp;
}
void QNA_tool::query(string question, string filename){
    // Implement your function here  
    std::cout << "Q: " << question << std::endl;
    std::cout << "A: " << "Studying COL106 :)" << std::endl;
    return;
}

std::string QNA_tool::get_paragraph(int book_code, int page, int paragraph){

    cout << "Book_code: " << book_code << " Page: " << page << " Paragraph: " << paragraph << endl;
    
    std::string filename = "mahatma-gandhi-collected-works-volume-";
    filename += to_string(book_code);
    filename += ".txt";

    std::ifstream inputFile(filename);

    std::string tuple;
    std::string sentence;

    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open the input file " << filename << "." << std::endl;
        exit(1);
    }

    std::string res = "";

    while (std::getline(inputFile, tuple, ')') && std::getline(inputFile, sentence)) {
        // Get a line in the sentence
        tuple += ')';

        int metadata[5];
        std::istringstream iss(tuple);

        // Temporary variables for parsing
        std::string token;

        // Ignore the first character (the opening parenthesis)
        iss.ignore(1);

        // Parse and convert the elements to integers
        int idx = 0;
        while (std::getline(iss, token, ',')) {
            // Trim leading and trailing white spaces
            size_t start = token.find_first_not_of(" ");
            size_t end = token.find_last_not_of(" ");
            if (start != std::string::npos && end != std::string::npos) {
                token = token.substr(start, end - start + 1);
            }
            
            // Check if the element is a number or a string
            if (token[0] == '\'') {
                // Remove the single quotes and convert to integer
                int num = std::stoi(token.substr(1, token.length() - 2));
                metadata[idx] = num;
            } else {
                // Convert the element to integer
                int num = std::stoi(token);
                metadata[idx] = num;
            }
            idx++;
        }

        if(
            (metadata[0] == book_code) &&
            (metadata[1] == page) &&
            (metadata[2] == paragraph)
        ){
            res += sentence;
        }
    }

    inputFile.close();
    return res;
}

void QNA_tool::query_llm(string filename, Node* root, int k, string API_KEY, string question){

    // first write the k paragraphs into different files

    Node* traverse = root;
    int num_paragraph = 0;

    while(num_paragraph < k){
        assert(traverse != nullptr);
        string p_file = "paragraph_";
        p_file += to_string(num_paragraph);
        p_file += ".txt";
        // delete the file if it exists
        remove(p_file.c_str());
        ofstream outfile(p_file);
        string paragraph = get_paragraph(traverse->book_code, traverse->page, traverse->paragraph);
        assert(paragraph != "$I$N$V$A$L$I$D$");
        outfile << paragraph;
        outfile.close();
        traverse = traverse->right;
        num_paragraph++;
    }

    // write the query to query.txt
    ofstream outfile("query.txt");
    outfile << "These are the excerpts from Mahatma Gandhi's books.\nOn the basis of this, ";
    outfile << question;
    // You can add anything here - show all your creativity and skills of using ChatGPT
    outfile.close();
 
    // you do not need to necessarily provide k paragraphs - can configure yourself

    // python3 <filename> API_KEY num_paragraphs query.txt
    string command = "python3 ";
    command += filename;
    command += " ";
    command += API_KEY;
    command += " ";
    command += to_string(k);
    command += " ";
    command += "query.txt";

    system(command.c_str());
    return;
}
// int main(){
    
//     return 0;
// }