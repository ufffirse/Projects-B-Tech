
#include<iostream>
#include "stack_c.h"



Stack_C::Stack_C() : stk(new List()) {}


Stack_C::~Stack_C(){
    delete stk;
}

void Stack_C::push(int data){
    stk->insert(data);
}
int Stack_C::pop(){
    if(stk->get_size()==0){
            throw std::runtime_error("Empty Stack");  
        }
    return stk->delete_tail();
}

    int Stack_C::get_element_from_top(int idx){
        Node* x=stk->get_head();
    for(int i=0;i<(stk->get_size())-idx;i++){
    x=x->next;
    }
    return x->get_value();
    }

    int Stack_C::get_element_from_bottom(int idx){
         Node* x=stk->get_head();
    for(int i=0;i<(idx+1);i++){
    x=x->next;
    }
    return x->get_value();
    }
    

    void Stack_C::print_stack(bool top_or_bottom){
        //if bool =false elements are printed from top of stack
       if(!top_or_bottom){
        Node* x=stk->get_head();
        for(int i=0;i<stk->get_size();i++){
        x=x->next;
        std::cout<<(x->get_value())<<" ";
        }
    }
    else{
        Node* x=stk->get_head();
        for(int i=0;i<stk->get_size();i++){
        x=x->next;
        }
    for(int i=0;i<stk->get_size();i++){
        std::cout<<(x->get_value())<<" ";
        x=x->prev;
        }
    }
    }

int Stack_C::add(){
    if(stk->get_size()<=1){
          throw std::runtime_error("Not Enough Arguments");
        }
    int a=stk->delete_tail();
    int b=stk->delete_tail();
int c=a+b;
// std::cout<<a<<b<<c;
    stk->insert(c);
    return c;
}

    int Stack_C::subtract(){
        if(stk->get_size()<=1){
          throw std::runtime_error("Not Enough Arguments");
        }
    int a=stk->delete_tail();
    int b=stk->delete_tail();
int c=b-a;
    stk->insert(c);
    return c;
}

    int Stack_C::multiply(){
        if(stk->get_size()<=1){
          throw std::runtime_error("Not Enough Arguments");
        }
          int a=stk->delete_tail();
    int b=stk->delete_tail();
int c=b*a;
    stk->insert(c);
    return c;
}
    

    int Stack_C::divide(){
        if(stk->get_size()<=1){
          throw std::runtime_error("Not Enough Arguments");
        }
           int a=stk->delete_tail();
           if(a==0){
            throw std::runtime_error("Divide by Zero Error");
           }
    int b=stk->delete_tail();
    int c;
    if(a*b<0){
       if(b%a==0){
         c= b/a;
         stk->insert(c);
            return c;
          }
          else{
            c=(-1+(b/a));
            stk->insert(c);
            return c;
            }
        }
     
    else{
    c=b/a;
    stk->insert(c);
    return c;
    }
    }
    

    List* Stack_C::get_stack(){
      return stk;
    } // Get a pointer to the linked list representing the stack

    int Stack_C::get_size(){
        return stk->get_size();
    } // Get the size of the stack
