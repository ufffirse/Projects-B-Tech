// Do NOT add any other includes
#include "search.h"

SearchEngine::SearchEngine(){
 
}

SearchEngine::~SearchEngine(){
    // Implement your function here  
}

void SearchEngine::insert_sentence(int b_code, int pg, int para, int s_no, string sen){
  
    
}
Node* SearchEngine::search(vector<string> words,int k){
return nullptr;
}
