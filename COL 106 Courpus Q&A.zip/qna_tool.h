#pragma once
#include <iostream>
#include <fstream>
#include "Node.h"
#include "dict.h"
#include "search.h"
using namespace std;
struct tup{
  Node* ra;
  long double score;
};
class   parag{
public:
Node* par;
Dict k;
  parag(int b_code, int pg, int paa){
  k.assig(147);
  par=new Node(b_code,pg,paa,-1,-1);
  }
 void add(string st){
  k.insert_sentence(st);
 }
 long double score(vector<string> words, Dict &cor) {
    long double out = 0;
    
    for (string& w : words) {
        long double scr = cor.get_scr(w);
        long double count = k.get_word_count(w);
        out = out + scr * count;
    }
    return out;
}
};
class heap{
    public:
vector<tup> v;
int capa;
int size;
    heap(int k){
        v.resize(k);
        capa=k;
        size=0;
    }
    void swap( tup&a, tup&b) {
        tup temp = a;
        a = b;
        b = temp;
    }

  int getParentIndex(int i) {
    return (i - 1) / 2;
  }
  
  int getLeftChildIndex(int i) {
    return 2 * i + 1;
  }
  
  int getRightChildIndex(int i) {
    return 2 * i + 2;
  }
    void heapifyDown(int n, int index) {
    int leftChild = getLeftChildIndex(index);
    int rightChild = getRightChildIndex(index);
    
    int minIndex = index;
    
    if (leftChild < n && v[minIndex].score > v[leftChild].score) {
      minIndex = leftChild;
    }
    
    if (rightChild < n && v[minIndex].score > v[rightChild].score) {
      minIndex = rightChild;
    }
    
    if (minIndex != index) {
      swap(v[minIndex], v[index]);
      heapifyDown(n, minIndex);
    }
  }
   void heapifyUp(int index) {
    if (index == 0) return; // base condition for termination of a recursive invocation of the fnc
    
    int parentIndex = getParentIndex(index);
    
    if (v[parentIndex].score > v[index].score) {
      swap(v[parentIndex], v[index]);
      heapifyUp(parentIndex);
    }
  }
    void push(Node* k,long double scr){
        tup m;
        m.ra=k;
        m.score=scr;
        if(size<capa){
            v[size]=m;
            size++;
            heapifyUp(size-1);
            return;
        }

        if(scr>v[0].score){
            v[0].ra=k;
            v[0].score=scr;
            heapifyDown(size,0);
        }
    }
    Node* get(){
        Node* temp=v[0].ra;
        v[0]=v[size-1];
        size--;
        heapifyDown(size,0);
        return temp;
    }
    
};
class QNA_tool {

private:
    vector<parag> vec;
    Dict kam; 
    // You are free to change the implementation of this function
    void query_llm(string filename, Node* root, int k, string API_KEY, string question);
    // filename is the python file which will call ChatGPT API
    // root is thde head of the linked list of paragraphs
    // k is the number of paragraphs (or the number of nodes in linked list)
    // API_KEY is the API key for ChatGPT
    // question is the question asked by the user

    // You can add attributes/helper functions here

public:
    bool process;
    void processCSVFile(const std::string &filename) {
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }
    
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string str;
            long double num;
        if (std::getline(iss, str, ',') && (iss >> num)) {
            kam.set_uni(str,num);
        } else {
            std::cerr << "Error parsing line: " << line << std::endl;
            // Handle the error or skip the line as needed
        }
       
    }

    file.close();
}
    /* Please do not touch the attributes and
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    QNA_tool(); // Constructor
    ~QNA_tool(); // Destructor

    void insert_sentence(int book_code, int page, int paragraph, int sentence_no, string& sentence);
    // This function is similar to the functions in dict and search 
    // The corpus will be provided to you via this function
    // It will be called for each sentence in the corpus

    Node* get_top_k_para(string question, int k);
    // This function takes in a question, preprocess it
    // And returns a list of paragraphs which contain the question
    // In each Node, you must set: book_code, page, paragraph (other parameters won't be checked)
    
    std::string get_paragraph(int book_code, int page, int paragraph);
    // Given the book_code, page number, and the paragraph number, returns the string paragraph.
    // Searches through the corpus.

    void query(string question, string filename);
    // This function takes in a question and a filename.
    /* -----------------------------------------*/
    /* Please do not touch the code above this line */

    // You can add attributes/helper functions here
};