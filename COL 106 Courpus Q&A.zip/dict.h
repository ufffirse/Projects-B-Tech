// Do NOT add any other includes
#include <string> 
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


struct kev
{
    string key;
    int count;
    long double score;
};

class Dict {
private:
    int hash_djb1(string& k,int size ) {
    unsigned long hash = 5381;
    for(char& c: k) {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }
    return (hash%size);
}
    // You can add attributes/helper functions here

public: 

   vector<vector<kev>> chain;
    /* Please do not touch the attributes and 
    functions within the guard lines placed below  */
    /* ------------------------------------------- */
    void set_uni(string& word,long double c){

    int h=hash_djb1(word,size);
            for(auto& mona : chain[h]){
                if(mona.key==word){
                    mona.score=(mona.count+1)/(c+1);
                }
            }
}
 long double get_scr(string word){
   int h=hash_djb1(word,size);
            for(auto& mona : chain[h]){
                if(mona.key==word){
                    return mona.score;
                }
            }
            return 0;
}
    int size;
    Dict();

    ~Dict();
    void assig(int k);
    void insert_sentence(string& sentence);

    int get_word_count(string& word);

    void dump_dictionary(string filename);

    /* -----------------------------------------*/
};
