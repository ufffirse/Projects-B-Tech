// Do NOT add any other includes
#include "dict.h"
#include "fstream"

int hash_djb2(string& k,int size ) {
    unsigned long hash = 5381;
    for(char c: k) {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }
    return (hash%size);
}
Dict::Dict(){
 
}
void Dict::assig(int k){
    size=k;
    chain.resize(k);
}
Dict::~Dict(){
   
}

void Dict::insert_sentence( string& sentence){
 string beta="";
 int h;
 for(char& c : sentence){
    if(isalpha(c)){
        c=tolower(c);
        beta=beta+c;
    }
    else{
        if(!beta.empty()){
            h=hash_djb2(beta,size);
            bool found=false;
            for(kev& mona : chain[h]){
                if(mona.key==beta){
                    found=true;
                    mona.count=mona.count+1;
                }
            }
            if(!found){
                kev mona;
                mona.key=beta;
                mona.count=1;
                chain[h].push_back(mona);
            }
            found=false;
            beta="";
        }
    }
 }  
   if(!beta.empty()){
            h=hash_djb2(beta,size);
            bool found=false;
            for(auto& mona : chain[h]){
                if(mona.key==beta){
                    found=true;
                    mona.count=mona.count+1;
                }
            }
            if(!found){
                kev mona;
                mona.key=beta;
                mona.count=1;
                chain[h].push_back(mona);
            }
            found=false;
           beta="";
        }
}

int Dict::get_word_count(string& word){
   int h=hash_djb2(word,size);
            bool found=false;
            for(auto& mona : chain[h]){
                if(mona.key==word){
                    return mona.count;
                }
            }
            return 0;
}

void Dict::dump_dictionary(string filename){
   
}
// int main(){
//     Dict mona;
//     mona.assig(100000);
//      std::ifstream inputFile("input.txt");

//     // Check if the file is open
//     if (!inputFile.is_open()) {
//         std::cerr << "Error opening the file!" << std::endl;
//         return 1; // return an error code
//     }

//     // Declare a variable to store each line read from the file
//     std::string line;
//     int i=0;
//     // Read lines from the file using getline
//     while (std::getline(inputFile, line)) {
//         i++;
//         cout<<i<<endl;
//        mona.insert_sentence(line);
//     }

//     ofstream outputFile("hem.txt");

//     // Check if the file is open
//     if (!outputFile.is_open()) {
        
//         std::cerr << "Error opening the file for writing!" << std::endl;
//         return 1; // return an error code
//     }
//     for(auto m : mona.chain){
//         for(kev km : m){
//             outputFile<<km.key<<" "<<km.count<<endl;
//         }
//     }
//     // Close the file
//     outputFile.close();
//     inputFile.close();

//     return 0;
// }
